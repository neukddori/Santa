#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""시안 합성용 UI 드로잉 헬퍼 (PIL). 논리 좌표 1600x900 기준, SS배 슈퍼샘플 후 축소."""
import os
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
FONTS = {
    "R": os.path.join(ROOT, "fonts/Pretendard-Regular.otf"),
    "S": os.path.join(ROOT, "fonts/Pretendard-SemiBold.otf"),
    "B": os.path.join(ROOT, "fonts/Pretendard-Bold.otf"),
    "E": os.path.join(ROOT, "fonts/Pretendard-ExtraBold.otf"),
}
EMOJI = "/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf"

SS = 2


def L(v):
    return int(round(v * SS))


@lru_cache(maxsize=256)
def font(weight, size):
    return ImageFont.truetype(FONTS[weight], L(size))


@lru_cache(maxsize=512)
def emoji_img(ch, size_px):
    f = ImageFont.truetype(EMOJI, 109)
    tmp = Image.new("RGBA", (220, 220), (0, 0, 0, 0))
    ImageDraw.Draw(tmp).text((20, 20), ch, font=f, embedded_color=True)
    bb = tmp.getbbox()
    if bb is None:
        return None
    tmp = tmp.crop(bb)
    w, h = tmp.size
    nh = size_px
    nw = max(1, int(round(w * nh / h)))
    return tmp.resize((nw, nh), Image.LANCZOS)


def tw(s, f):
    b = f.getbbox(s)
    return b[2] - b[0]


def text(layer, xy, s, size, weight="B", fill=(255, 255, 255, 255), anchor="la",
         shadow=None, sh_off=(0, 3), sh_blur=6):
    f = font(weight, size)
    x, y = L(xy[0]), L(xy[1])
    if shadow:
        sh = Image.new("RGBA", layer.size, (0, 0, 0, 0))
        ImageDraw.Draw(sh).text((x + L(sh_off[0]), y + L(sh_off[1])), s, font=f, fill=shadow, anchor=anchor)
        sh = sh.filter(ImageFilter.GaussianBlur(L(sh_blur))) if sh_blur else sh
        layer.alpha_composite(sh)
    ImageDraw.Draw(layer).text((x, y), s, font=f, fill=fill, anchor=anchor)
    return tw(s, f) / SS


def emoji(layer, ch, cx, cy, size, anchor="mm"):
    im = emoji_img(ch, L(size))
    if im is None:
        return
    w, h = im.size
    if anchor == "mm":
        x, y = L(cx) - w // 2, L(cy) - h // 2
    elif anchor == "lm":
        x, y = L(cx), L(cy) - h // 2
    elif anchor == "rm":
        x, y = L(cx) - w, L(cy) - h // 2
    else:
        x, y = L(cx), L(cy)
    layer.alpha_composite(im, (x, y))
    return w / SS, h / SS


def rrect_mask(size, radius):
    m = Image.new("L", size, 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, size[0] - 1, size[1] - 1], radius=radius, fill=255)
    return m


def vgrad(size, top, bottom):
    g = Image.new("RGBA", (1, size[1]))
    d = ImageDraw.Draw(g)
    for y in range(size[1]):
        t = y / max(1, size[1] - 1)
        d.point((0, y), tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(4)))
    return g.resize(size)


def fill_rrect(layer, box, radius, fill, outline=None, width=0):
    x0, y0, x1, y1 = [L(v) for v in box]
    w, h = x1 - x0, y1 - y0
    if w <= 0 or h <= 0:
        return
    if len(fill) == 4 and fill[3] < 255:
        solid = Image.new("RGBA", (w, h), fill)
        m = rrect_mask((w, h), L(radius))
        solid.putalpha(ImageChops.multiply(solid.getchannel("A"), m))
        layer.alpha_composite(solid, (x0, y0))
    else:
        ImageDraw.Draw(layer).rounded_rectangle([x0, y0, x1, y1], radius=L(radius), fill=fill)
    if outline:
        ImageDraw.Draw(layer).rounded_rectangle([x0, y0, x1 - 1, y1 - 1], radius=L(radius),
                                                outline=outline, width=L(width) if width else 0)


def grad_rrect(layer, box, radius, top, bottom, outline=None, width=0):
    x0, y0, x1, y1 = [L(v) for v in box]
    w, h = x1 - x0, y1 - y0
    if w <= 0 or h <= 0:
        return
    g = vgrad((w, h), top, bottom)
    m = rrect_mask((w, h), L(radius))
    g.putalpha(ImageChops.multiply(g.getchannel("A"), m))
    layer.alpha_composite(g, (x0, y0))
    if outline:
        ImageDraw.Draw(layer).rounded_rectangle([x0, y0, x1 - 1, y1 - 1], radius=L(radius),
                                                outline=outline, width=L(width) if width else L(1.5))


def drop_shadow(layer, box, radius, color=(4, 12, 40, 120), blur=14, off=(0, 8)):
    x0, y0, x1, y1 = [L(v) for v in box]
    sh = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([x0 + L(off[0]), y0 + L(off[1]), x1 + L(off[0]), y1 + L(off[1])],
                                         radius=L(radius), fill=color)
    sh = sh.filter(ImageFilter.GaussianBlur(L(blur)))
    layer.alpha_composite(sh)


def glass(layer, box, radius, tint=(15, 26, 64, 140), blur=16, border=(255, 255, 255, 115), bw=1.6,
          shine=True, shadow=True):
    x0, y0, x1, y1 = [L(v) for v in box]
    w, h = x1 - x0, y1 - y0
    if shadow:
        drop_shadow(layer, box, radius, color=(4, 12, 40, 110), blur=18, off=(0, 10))
    region = layer.crop((x0, y0, x1, y1)).convert("RGBA").filter(ImageFilter.GaussianBlur(L(blur)))
    t = Image.new("RGBA", (w, h), tint)
    region = Image.alpha_composite(region, t)
    if shine:
        hi = vgrad((w, h), (255, 255, 255, 55), (255, 255, 255, 0))
        region = Image.alpha_composite(region, hi)
    m = rrect_mask((w, h), L(radius))
    layer.paste(region, (x0, y0), m)
    ImageDraw.Draw(layer).rounded_rectangle([x0, y0, x1 - 1, y1 - 1], radius=L(radius),
                                            outline=border, width=L(bw))


def btn3d(layer, box, radius, top, bottom, text_s, size=21, weight="E", color=(60, 40, 10, 255),
          e=None, e_size=27, shadow=(3, 10, 40, 110), pad=26, gap=11):
    x0, y0, x1, y1 = box
    drop_shadow(layer, box, radius, color=shadow, blur=12, off=(0, 7))
    grad_rrect(layer, box, radius, top, bottom)
    # 상단 하이라이트
    hi_box = (x0 + 2, y0 + 2, x1 - 2, y0 + (y1 - y0) * 0.50)
    grad_rrect(layer, hi_box, radius - 2, (255, 255, 255, 92), (255, 255, 255, 0))
    f = font(weight, size)
    twidth = tw(text_s, f) / SS
    total = twidth + (e_size + gap if e else 0)
    cx = (x0 + x1) / 2
    tx = cx - total / 2 + (e_size + gap if e else 0)
    if e:
        emoji(layer, e, tx - gap - e_size / 2, (y0 + y1) / 2, e_size, anchor="mm")
    cy = (y0 + y1) / 2 - size * 0.04
    ImageDraw.Draw(layer).text((L(tx), L(cy)), text_s, font=f, fill=color, anchor="lm")


def pill(layer, box, radius, fill, stroke=None, bw=1.5):
    fill_rrect(layer, box, radius, fill, stroke, bw)


def tag(layer, name, cx, head_y, me=False, size=17):
    """눈사람 머리 위 이름표(말풍선)"""
    f = font("E", size)
    w = tw(name, f) / SS + 28
    h = size * 1.95
    x0, x1 = cx - w / 2, cx + w / 2
    y0, y1 = head_y - h - 10, head_y - 10
    drop_shadow(layer, (x0, y0, x1, y1), 14, color=(6, 16, 50, 105), blur=7, off=(0, 4))
    if me:
        grad_rrect(layer, (x0, y0, x1, y1), 14, (255, 249, 205, 255), (255, 216, 118, 255),
                   outline=(255, 255, 255, 255), width=1.6)
        d = ImageDraw.Draw(layer)
        d.polygon([(L(cx - 7), L(y1 - 1)), (L(cx + 7), L(y1 - 1)), (L(cx), L(y1 + 8))], fill=(255, 216, 118, 255))
        fill = (92, 56, 0, 255)
    else:
        fill_rrect(layer, (x0, y0, x1, y1), 14, (255, 255, 255, 246), outline=(255, 255, 255, 255), width=1.6)
        d = ImageDraw.Draw(layer)
        d.polygon([(L(cx - 7), L(y1 - 1)), (L(cx + 7), L(y1 - 1)), (L(cx), L(y1 + 8))], fill=(255, 255, 255, 246))
        fill = (34, 49, 92, 255)
    ImageDraw.Draw(layer).text((L(cx), L((y0 + y1) / 2)), name, font=f, fill=fill, anchor="mm")


def switch(layer, x, y, w=44, h=24, on=True):
    grad_rrect(layer, (x, y, x + w, y + h), h / 2,
               (94, 242, 166, 255) if on else (150, 160, 185, 255),
               (55, 217, 140, 255) if on else (120, 130, 158, 255))
    kx = x + w - h + 3 if on else x + 3
    drop_shadow(layer, (kx, y + 3, kx + h - 6, y + h - 3), (h - 6) / 2, color=(0, 0, 0, 70), blur=3, off=(0, 1))
    fill_rrect(layer, (kx, y + 3, kx + h - 6, y + h - 3), (h - 6) / 2, (255, 255, 255, 255))


def cover(im, size):
    W, H = size
    sw, sh = im.size
    s = max(W / sw, H / sh)
    im = im.resize((int(sw * s + .5), int(sh * s + .5)), Image.LANCZOS)
    x = (im.width - W) // 2
    y = (im.height - H) // 2
    return im.crop((x, y, x + W, y + H))


def snowflakes(layer, n=70, seed=7, color=(255, 255, 255, 210), rmin=1.2, rmax=4.0):
    import random
    rnd = random.Random(seed)
    d = ImageDraw.Draw(layer)
    for _ in range(n):
        x = rnd.uniform(0, layer.width)
        y = rnd.uniform(0, layer.height)
        r = L(rnd.uniform(rmin, rmax))
        a = int(color[3] * rnd.uniform(.45, 1))
        d.ellipse([x - r, y - r, x + r, y + r], fill=color[:3] + (a,))
