#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""선생님 큰 화면 시안 합성: 눈마을 광장 + HUD"""
import os, sys
from PIL import Image, ImageDraw, ImageFilter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mockui as U
from mockui import L

HERE = os.path.dirname(os.path.abspath(__file__))
W, H = L(1600), L(900)

canvas = U.cover(Image.open(os.path.join(HERE, "_bg_teacher.png")).convert("RGBA"), (W, H))

# ── 상·하단 셰이드
for (y0, y1, a0, a1) in [(0, 180, 165, 0), (620, 900, 0, 150)]:
    strip = U.vgrad((W, L(y1 - y0)), (8, 15, 42, a0), (8, 15, 42, a1))
    canvas.alpha_composite(strip, (0, L(y0)))

# ── 눈사람 이름표 (머리 위)
for name, fx, fy, me in [
    ("민준", 95, 645, True), ("서연", 218, 632, False), ("하린", 700, 692, False),
    ("지우", 645, 612, False), ("하준", 722, 606, False), ("수아", 890, 626, True),
    ("도윤", 970, 616, False), ("건우", 930, 674, False), ("예린", 1045, 614, False),
    ("시우", 1364, 553, False), ("지호", 1429, 495, False), ("유나", 1525, 508, False),
]:
    U.tag(canvas, name, fx, fy, me=me)

# ── 구역 라벨
def zone(x, y, label, e):
    f = U.font("E", 16)
    w = U.tw(label, f) / U.SS + 56
    box = (x, y, x + w, y + 40)
    U.glass(canvas, box, 14, tint=(10, 22, 56, 120), blur=6, border=(255, 255, 255, 120), bw=1.4, shine=False, shadow=False)
    U.emoji(canvas, e, x + 24, y + 20, 22)
    U.text(canvas, (x + 42, y + 20), label, 16, "E", (255, 255, 255, 255), anchor="lm",
           shadow=(5, 12, 40, 150), sh_off=(0, 1), sh_blur=3)
    return w

zone(40, 540, "눈싸움 구역", "❄️")
zone(1272, 694, "썰매 구역", "🛷")
# 하늘 중앙 안내 (유리 알약)
msg = "소원 등불이 별빛으로 올라가는 중…"
fm = U.font("B", 16.5)
mw = U.tw(msg, fm) / U.SS + 76
mh = 44
mx, my = 800 - mw / 2, 214
U.glass(canvas, (mx, my, mx + mw, my + mh), 22, tint=(10, 20, 52, 110), blur=8,
        border=(255, 255, 255, 105), bw=1.3, shine=False, shadow=False)
U.emoji(canvas, "🏮", mx + 26, my + mh / 2, 23)
U.text(canvas, (mx + 46, my + mh / 2), msg, 16.5, "B", (255, 236, 176, 255), anchor="lm")

# ── 상단 HUD
bx0, by0 = 30, 24
bw, bh = 322, 74
U.glass(canvas, (bx0, by0, bx0 + bw, by0 + bh), 22, tint=(16, 27, 66, 135), blur=14)
U.grad_rrect(canvas, (bx0 + 12, by0 + 11, bx0 + 12 + 54, by0 + 11 + 54), 17,
             (150, 218, 255, 255), (72, 140, 240, 255), outline=(255, 255, 255, 200), width=1.4)
U.emoji(canvas, "⛄", bx0 + 39, by0 + 38, 36)
U.text(canvas, (bx0 + 80, by0 + 22), "몽글 눈마을", 29, "E", (255, 255, 255, 255), anchor="lm",
       shadow=(3, 10, 40, 200), sh_off=(0, 2), sh_blur=6)
# 라이브
dy = by0 + 52
ImageDraw.Draw(canvas).ellipse([L(bx0 + 81), L(dy - 4), L(bx0 + 90), L(dy + 5)], fill=(94, 242, 166, 255))
U.text(canvas, (bx0 + 99, dy), "42/50", 16.5, "E", (143, 247, 196, 255), anchor="lm")
U.text(canvas, (bx0 + 148, dy), "명 접속 중", 16.5, "B", (216, 240, 255, 255), anchor="lm")

# BGM 필
f = U.font("B", 17)
bgm_w = 250
gx0 = 1570 - bgm_w
U.glass(canvas, (gx0, by0 + 8, gx0 + bgm_w, by0 + 8 + 54), 18, tint=(16, 27, 66, 135), blur=14)
U.emoji(canvas, "🎵", gx0 + 30, by0 + 35, 24)
U.text(canvas, (gx0 + 50, by0 + 35), "캐롤 BGM", 17, "B", (255, 255, 255, 255), anchor="lm")
U.text(canvas, (gx0 + 150, by0 + 35), "ON", 15.5, "E", (143, 247, 196, 255), anchor="lm")
U.switch(canvas, gx0 + 184, by0 + 23, 42, 24, True)

# ── 실시간 토스트
tx0, ty0 = 1160, 102
U.drop_shadow(canvas, (tx0, ty0, tx0 + 404, ty0 + 76), 20, color=(5, 14, 45, 120), blur=14, off=(0, 8))
U.fill_rrect(canvas, (tx0, ty0, tx0 + 404, ty0 + 76), 20, (255, 255, 255, 248), outline=(255, 255, 255, 255), width=1)
U.grad_rrect(canvas, (tx0 + 12, ty0 + 15, tx0 + 12 + 46, ty0 + 15 + 46), 14,
             (198, 232, 255, 255), (126, 180, 240, 255))
U.emoji(canvas, "⛄", tx0 + 35, ty0 + 38, 30)
U.text(canvas, (tx0 + 72, ty0 + 28), "지우 님이 눈사람을 보냈어요!", 16.5, "B", (36, 52, 95, 255), anchor="lm")
U.text(canvas, (tx0 + 72, ty0 + 52), "방금 도착 · 마을 눈사람 42개", 13.5, "S", (139, 151, 184, 255), anchor="lm")

# ── 하단 버튼 독
labels = [("🏮", "소원 등불 띄우기", (255, 233, 163, 255), (255, 194, 71, 255), (93, 59, 0, 255)),
          ("❄️", "눈싸움 시작", (216, 240, 255, 255), (142, 201, 246, 255), (18, 58, 94, 255)),
          ("🛷", "썰매 타임", (255, 210, 221, 255), (255, 147, 173, 255), (92, 18, 41, 255))]
sizes = []
for e, label, *_ in labels:
    sizes.append(U.tw(label, U.font("E", 20.5)) / U.SS + 27 + 11 + 46)
pad, gapb = 16, 14
dock_w = sum(sizes) + gapb * 2 + pad * 2
dock_h = 92
dx0 = (1600 - dock_w) / 2
dy0 = 900 - 26 - dock_h
U.glass(canvas, (dx0, dy0, dx0 + dock_w, dy0 + dock_h), 26, tint=(12, 22, 56, 125), blur=18)
cx = dx0 + pad
for (e, label, t, b, c), w in zip(labels, sizes):
    U.btn3d(canvas, (cx, dy0 + 14, cx + w, dy0 + dock_h - 14), 18, t, b, label, 20.5, "E", c, e, 26)
    cx += w + gapb

# ── 저장 (1920x1080)
out = canvas.convert("RGB").resize((1920, 1080), Image.LANCZOS)
p = os.path.join(HERE, "teacher_village_mockup.png")
out.save(p, optimize=True)
print("saved", p, out.size)
