#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""학생용 화면 시안 합성: 나만의 눈사람 꾸미기 + 체험 메뉴"""
import os, sys
from PIL import Image, ImageDraw, ImageFilter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mockui as U
from mockui import L

HERE = os.path.dirname(os.path.abspath(__file__))
W, H = L(1600), L(900)

NAVY = (30, 44, 80, 255)
GRAY = (140, 152, 182, 255)
BLUE = (74, 134, 247, 255)

# ── 배경: 마을 흐리게 + 남색 그라데이션
bg = U.cover(Image.open(os.path.join(HERE, "_bg_teacher.png")).convert("RGBA"), (W, H))
bg = bg.filter(ImageFilter.GaussianBlur(L(11)))
canvas = bg.copy()
canvas.alpha_composite(U.vgrad((W, H), (9, 18, 48, 214), (12, 24, 60, 150)))
U.snowflakes(canvas, n=90, seed=3, color=(255, 255, 255, 200), rmin=1.2, rmax=3.6)

# ── 헤더
U.emoji(canvas, "⛄", 62, 60, 44)
U.text(canvas, (96, 44), "나만의 눈사람 만들기", 30, "E", (255, 255, 255, 255), anchor="lm",
       shadow=(4, 12, 40, 190), sh_off=(0, 2), sh_blur=8)
U.text(canvas, (98, 78), "이름을 쓰고 모자와 목도리를 골라 보세요!", 15.5, "S", (198, 220, 255, 255), anchor="lm")

# 헤더 우측: 접속 현황
hw = 236
U.glass(canvas, (1570 - hw, 34, 1570, 34 + 54), 18, tint=(12, 22, 56, 130), blur=12)
ImageDraw.Draw(canvas).ellipse([L(1570 - hw + 22), L(56), L(1570 - hw + 32), L(66)], fill=(94, 242, 166, 255))
U.text(canvas, (1570 - hw + 42, 61), "마을에 친구", 15.5, "B", (216, 236, 255, 255), anchor="lm")
U.text(canvas, (1570 - hw + 130, 61), "42명", 15.5, "E", (143, 247, 196, 255), anchor="lm")
U.text(canvas, (1570 - hw + 168, 61), "있어요", 15.5, "B", (216, 236, 255, 255), anchor="lm")

# ══ 왼쪽 카드: 나만의 눈사람
card = (56, 116, 936, 800)
U.drop_shadow(canvas, card, 30, color=(4, 12, 40, 130), blur=22, off=(0, 14))
U.fill_rrect(canvas, card, 30, (255, 255, 255, 246))

U.emoji(canvas, "⛄", 90, 163, 26)
U.text(canvas, (110, 163), "나만의 눈사람", 25, "E", NAVY, anchor="lm")
U.text(canvas, (936 - 26, 165), "친구들도 같이 보고 있어요", 14, "S", GRAY, anchor="rm")

# 미리보기 박스
pv = (78, 200, 430, 662)
U.fill_rrect(canvas, pv, 24, (226, 242, 255, 255))
av = U.cover(Image.open(os.path.join(HERE, "_avatar_snowman.png")).convert("RGBA"), (L(pv[2] - pv[0]), L(pv[3] - pv[1])))
mask = U.rrect_mask(av.size, L(24))
canvas.paste(av, (L(pv[0]), L(pv[1])), mask)
ImageDraw.Draw(canvas).rounded_rectangle([L(pv[0]), L(pv[1]), L(pv[2]) - 1, L(pv[3]) - 1],
                                         radius=L(24), outline=(255, 255, 255, 255), width=L(3))
# 미리보기 위 이름표
U.tag(canvas, "민준", (pv[0] + pv[2]) / 2, 232, me=True, size=18)
# 미리보기 아래 작은 안내
U.text(canvas, (254, 626), "마음에 들면 마을로 보내요!", 13, "S", (96, 132, 186, 255), anchor="mm")

# ── 오른쪽: 꾸미기 옵션
x0, x1 = 456, 912


def row_label(y, s, e=None):
    tx = x0
    if e:
        U.emoji(canvas, e, x0 + 9, y, 17)
        tx = x0 + 22
    U.text(canvas, (tx, y), s, 14.5, "B", (108, 124, 160, 255), anchor="lm")


# 이름 입력
row_label(214, "이름", "✏️")
inp = (x0, 226, x1, 274)
U.fill_rrect(canvas, inp, 14, (246, 250, 255, 255), outline=(210, 228, 248, 255), width=1.6)
U.text(canvas, (x0 + 16, 250), "민준", 21, "E", NAVY, anchor="lm")
ImageDraw.Draw(canvas).rectangle([L(x0 + 72), L(240), L(x0 + 74), L(262)], fill=(74, 134, 247, 255))
U.text(canvas, (x1 - 14, 250), "한글 2~6자", 12.5, "S", (170, 184, 208, 255), anchor="rm")

# 모자
row_label(306, "모자", "🎩")
hats = [("🎅", "산타모자", True), ("🧢", "파란비니", False), ("👑", "왕관", False), ("🎀", "리본", False)]
cw, gap = 105, 10
for i, (e, label, sel) in enumerate(hats):
    cx0 = x0 + i * (cw + gap)
    box = (cx0, 320, cx0 + cw, 372)
    if sel:
        U.drop_shadow(canvas, box, 14, color=(74, 134, 247, 110), blur=8, off=(0, 4))
        U.fill_rrect(canvas, box, 14, (255, 255, 255, 255), outline=BLUE, width=2.6)
    else:
        U.fill_rrect(canvas, box, 14, (240, 246, 255, 255), outline=(222, 234, 250, 255), width=1.4)
    U.emoji(canvas, e, cx0 + cw / 2, 336, 24)
    U.text(canvas, (cx0 + cw / 2, 358), label, 12.5, "B", NAVY if sel else (120, 136, 168, 255), anchor="mm")

# 목도리 색
row_label(398, "목도리 색", "🧣")
sw = [("빨강", (232, 88, 96, 255), False), ("초록", (108, 178, 96, 255), True),
      ("파랑", (84, 142, 226, 255), False), ("노랑", (247, 196, 72, 255), False)]
for i, (label, col, sel) in enumerate(sw):
    cx = x0 + 26 + i * 74
    cy = 432
    if sel:
        ImageDraw.Draw(canvas).ellipse([L(cx - 26), L(cy - 26), L(cx + 26), L(cy + 26)], outline=BLUE, width=L(2.6))
    U.drop_shadow(canvas, (cx - 19, cy - 19, cx + 19, cy + 19), 19, color=(10, 20, 50, 70), blur=6, off=(0, 3))
    ImageDraw.Draw(canvas).ellipse([L(cx - 19), L(cy - 19), L(cx + 19), L(cy + 19)], fill=col,
                                   outline=(255, 255, 255, 255), width=L(2))
    ImageDraw.Draw(canvas).ellipse([L(cx - 9), L(cy - 13), L(cx + 1), L(cy - 5)], fill=(255, 255, 255, 90))

# 표정
row_label(492, "표정", "😊")
faces = [("😊", "웃음", True), ("😮", "놀람", False), ("😎", "멋짐", False), ("😴", "쿨쿨", False)]
for i, (e, label, sel) in enumerate(faces):
    cx0 = x0 + i * (cw + gap)
    box = (cx0, 506, cx0 + cw, 558)
    if sel:
        U.drop_shadow(canvas, box, 14, color=(74, 134, 247, 110), blur=8, off=(0, 4))
        U.fill_rrect(canvas, box, 14, (255, 255, 255, 255), outline=BLUE, width=2.6)
    else:
        U.fill_rrect(canvas, box, 14, (240, 246, 255, 255), outline=(222, 234, 250, 255), width=1.4)
    U.emoji(canvas, e, cx0 + cw / 2, 522, 24)
    U.text(canvas, (cx0 + cw / 2, 544), label, 12.5, "B", NAVY if sel else (120, 136, 168, 255), anchor="mm")

# 도움말
hint = (x0, 580, x1, 626)
U.fill_rrect(canvas, hint, 14, (255, 248, 226, 255), outline=(255, 226, 160, 255), width=1.2)
U.emoji(canvas, "💡", x0 + 24, 603, 18)
U.text(canvas, (x0 + 42, 603), "모자와 색은 언제든 다시 바꿀 수 있어요!", 13.5, "B", (150, 104, 24, 255), anchor="lm")

# 마을로 보내기 버튼 (카드 하단 전체)
cta = (78, 690, 912, 774)
U.btn3d(canvas, cta, 22, (255, 176, 199, 255), (255, 108, 150, 255), "마을로 보내기", 25, "E",
        (255, 255, 255, 255), "⛄", 30, shadow=(120, 20, 50, 120))

# ══ 오른쪽: 체험 메뉴
U.text(canvas, (972, 148), "오늘은 뭐 하고 놀까?", 24, "E", (255, 255, 255, 255), anchor="lm",
       shadow=(4, 12, 40, 190), sh_off=(0, 2), sh_blur=8)
U.text(canvas, (1570, 150), "4가지 놀이", 14, "B", (188, 212, 250, 255), anchor="rm")

cards = [
    ("❄️", "눈싸움", "친구랑 눈덩이 던지기", (168, 214, 255, 255), (116, 168, 246, 255)),
    ("🛷", "썰매 타기", "언덕에서 씽씽~", (188, 240, 214, 255), (108, 204, 148, 255)),
    ("⌨️", "겨울 타자 연습", "겨울 단어를 쳐 보기", (255, 226, 186, 255), (250, 178, 92, 255)),
    ("🏮", "소원 등불 적기", "내 소원을 하늘로", (255, 206, 216, 255), (246, 140, 170, 255)),
]
gx, gy = 972, 178
cwid, chei, cgap = 286, 202, 16
for i, (e, title, sub, t1, t2) in enumerate(cards):
    cx0 = gx + (i % 2) * (cwid + cgap)
    cy0 = gy + (i // 2) * (chei + cgap)
    box = (cx0, cy0, cx0 + cwid, cy0 + chei)
    U.drop_shadow(canvas, box, 26, color=(3, 10, 34, 120), blur=18, off=(0, 10))
    U.fill_rrect(canvas, box, 26, (255, 255, 255, 248))
    U.grad_rrect(canvas, (cx0 + 16, cy0 + 16, cx0 + 16 + 76, cy0 + 16 + 76), 22, t1, t2)
    U.emoji(canvas, e, cx0 + 54, cy0 + 54, 40)
    U.text(canvas, (cx0 + 20, cy0 + 118), title, 21, "E", NAVY, anchor="lm")
    U.text(canvas, (cx0 + 20, cy0 + 146), sub, 13.5, "S", GRAY, anchor="lm")
    # 꼬리 화살표 아이콘
    U.text(canvas, (cx0 + cwid - 20, cy0 + chei - 26), "놀러 가기 →", 12.5, "B", (110, 150, 220, 255), anchor="rm")

# 캐롤 토글
tg = (972, 604, 1570, 682)
U.drop_shadow(canvas, tg, 22, color=(3, 10, 34, 110), blur=16, off=(0, 8))
U.fill_rrect(canvas, tg, 22, (255, 255, 255, 240))
U.grad_rrect(canvas, (tg[0] + 14, tg[1] + 12, tg[0] + 14 + 56, tg[1] + 12 + 56), 18,
             (206, 232, 255, 255), (128, 182, 246, 255))
U.emoji(canvas, "🎵", tg[0] + 42, tg[1] + 40, 30)
U.text(canvas, (tg[0] + 84, tg[1] + 30), "캐롤 듣기", 19, "E", NAVY, anchor="lm")
U.text(canvas, (tg[0] + 84, tg[1] + 56), "크리스마스 캐롤 3곡 · 켜짐", 12.5, "S", GRAY, anchor="lm")
U.switch(canvas, tg[2] - 74, tg[1] + 27, 50, 28, True)

# 하단 안내
U.emoji(canvas, "🎄", 992, 722, 18)
U.text(canvas, (1010, 722), "보낸 눈사람은 선생님 큰 화면에 이름이랑 같이 나타나요!", 13.5, "B",
       (206, 226, 255, 255), anchor="lm")

out = canvas.convert("RGB").resize((1920, 1080), Image.LANCZOS)
p = os.path.join(HERE, "student_play_mockup.png")
out.save(p, optimize=True)
print("saved", p, out.size)
